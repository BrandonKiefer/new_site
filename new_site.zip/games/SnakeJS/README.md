# SnakeJS
JavaScript version of the classic game Snake that allows it to be played in web browsers
